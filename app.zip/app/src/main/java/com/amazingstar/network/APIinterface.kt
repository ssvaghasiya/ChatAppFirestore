package com.amazingstar.network

import com.amazingstar.base.datamodel.AllArea
import com.amazingstar.ui.login.datamodel.*
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.http.*


interface APIinterface {


    @GET("listing/area/{id}")
    fun getArea(
        @Path(
            value = "id",
            encoded = true
        ) id: String
    ): Call<AllArea>


    @GET("attendance/{employeeId}")
    fun getAttendance(@Path("employeeId") employeeId: Double)

    @GET("attendance/{employeeId}/{date}")
    fun getAttendanceForDate(@Path("employeeId") employeeId: Double, @Path("date") date: Double)


}