package com.amazingstar.exceptions.networks

class SocketTimeoutException: NetworkException() {

}