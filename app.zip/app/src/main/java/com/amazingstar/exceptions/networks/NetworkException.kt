package com.amazingstar.exceptions.networks

import com.amazingstar.exceptions.BaseException

open class NetworkException : BaseException() {


}