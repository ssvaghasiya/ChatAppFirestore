package com.amazingstar.ui.home.viewmodel


import android.app.*
import android.content.Context
import android.view.View
import android.widget.*
import com.amazingstar.R
import com.amazingstar.apputils.Utils
import com.amazingstar.base.viewmodel.BaseViewModel
import com.amazingstar.databinding.ActivityHomeBinding
import com.amazingstar.interfaces.TopBarClickListener



class HomeViewModel(application: Application) : BaseViewModel(application){

    private lateinit var binder: ActivityHomeBinding
    private lateinit var mContext: Context


    fun setBinder(binder: ActivityHomeBinding) {
        this.binder = binder
        this.mContext = binder.root.context
        this.binder.viewModel = this
        this.binder.viewClickHandler = ViewClickHandler()
        this.binder.topbar.topBarClickListener = SlideMenuClickListener()
        this.binder.topbar.isSettingShow = true
        this.binder.topbar.isCenterTextShow = true

        init()

    }

    private fun init() {

    }







    inner class SlideMenuClickListener : TopBarClickListener {
        override fun onTopBarClickListener(view: View?, value: String?) {
            Utils.hideKeyBoard(getContext(), view!!)
            if (value.equals(getLabelText(R.string.menu))) {
                try {
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }         }

        override fun onBackClicked(view: View?) {
            (mContext as Activity).finish()
        }
    }


    inner class ViewClickHandler {


        fun onSearch(view: View) {
            try {

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

    }


}



