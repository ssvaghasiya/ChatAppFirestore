package com.amazingstar.ui.login.viewmodel

import android.app.Activity
import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.View
import com.amazingstar.R
import com.amazingstar.apputils.Debug
import com.amazingstar.base.viewmodel.BaseViewModel
import com.amazingstar.databinding.ActivityLoginBinding
import com.amazingstar.validator.EmailValidator
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task

class LoginViewModel(application: Application) : BaseViewModel(application) {

    private lateinit var binder: ActivityLoginBinding
    private lateinit var mContext: Context
    private lateinit var mGoogleSignInClient: GoogleSignInClient
    private val RC_SIGN_IN: Int = 5001


    fun setBinder(binder: ActivityLoginBinding) {
        this.binder = binder
        this.mContext = binder.root.context
        this.binder.viewModel = this
        this.binder.viewClickHandler = ViewClickHandler()
        init()
    }

    private fun init() {
        if (Debug.DEBUG) {
            binder.edtUserEmail.setText("")
            binder.edtPassword.setText("")
        }

        initGoogle()

    }

    // Google
    private fun initGoogle() {
        // Configure sign-in to request the user's ID, email address, and basic
        // profile. ID and basic profile are included in DEFAULT_SIGN_IN.

        // Configure sign-in to request the user's ID, email address, and basic
        // profile. ID and basic profile are included in DEFAULT_SIGN_IN.
        val gso =
            GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build()

        // Build a GoogleSignInClient with the options specified by gso.
        mGoogleSignInClient = GoogleSignIn.getClient(mContext as Activity, gso);
    }


    private fun loginGoogle() {
        val signInIntent = mGoogleSignInClient.signInIntent
        (mContext as Activity).startActivityForResult(signInIntent, RC_SIGN_IN)
    }


    fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
//        super.onActivityResult(requestCode, resultCode, data)

        // Result returned from launching the Intent from GoogleSignInClient.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            // The Task returned from this call is always completed, no need to attach
            // a listener.
            val task: Task<GoogleSignInAccount> = GoogleSignIn.getSignedInAccountFromIntent(data)
            handleSignInResult(task)
        }
    }

    private fun handleSignInResult(completedTask: Task<GoogleSignInAccount>) {
        try {
            val account =
                completedTask.getResult(ApiException::class.java)

            // Signed in successfully, show authenticated UI.
//            updateUI(account)
            getGoogleProfile(account)
        } catch (e: ApiException) {
            // The ApiException status code indicates the detailed failure reason.
            // Please refer to the GoogleSignInStatusCodes class reference for more information.
            Debug.e("", "signInResult:failed code=" + e.statusCode)
//            updateUI(null)
        }
    }

    private fun getGoogleProfile(acct: GoogleSignInAccount?) {
//        val acct = GoogleSignIn.getLastSignedInAccount(mContext)
        if (acct != null) {
            val personName = acct.displayName
            val personGivenName = acct.givenName
            val personFamilyName = acct.familyName
            val providerToken = acct.idToken
            val personEmail = acct.email
            val personId = acct.id
            val personPhoto: Uri? = acct.photoUrl

            Debug.e("getGoogleProfile", "$personEmail $personName")

            // Do login social call here
//            FirebaseMessaging.getInstance().token
//                .addOnCompleteListener(OnCompleteListener { task ->
//                    if (!task.isSuccessful) {
//                        return@OnCompleteListener
//                    }
//                    // Get new Instance ID token
//                    val token = task.result
//
//                })
        }
    }

    inner class ViewClickHandler {

        fun onSignInClick(view: View) {
            try {
                if (isValidate()) {
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }


        fun onGoogleLogin(view: View) {
            loginGoogle()
        }

        fun onLogin(view: View) {
            try {
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun isValidate(): Boolean {
        val emailValidator = EmailValidator(binder.edtUserEmail.text.toString())
        if (!emailValidator.isValid()) {
            showToast(emailValidator.msg)
            return false
        } else if (binder.edtPassword.text.isNullOrEmpty()) {
            showToast(mContext.getString(R.string.password_field_is_require))
            return false
        }

        return true
    }

}
