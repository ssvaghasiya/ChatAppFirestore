package com.amazingstar.cacheUtil

object CacheUtils {


}