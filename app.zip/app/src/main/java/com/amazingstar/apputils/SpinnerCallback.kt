package com.amazingstar.apputils

import java.util.*



interface SpinnerCallback {
    fun onDone(list: ArrayList<Spinner>)
}