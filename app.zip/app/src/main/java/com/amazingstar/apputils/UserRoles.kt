package com.amazingstar.apputils

enum class UserRoles {
    ENDUSER, PROMOTOR, VENUEOWNER
}