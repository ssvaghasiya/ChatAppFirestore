package com.amazingstar.base.datamodel

import android.content.Context
import androidx.lifecycle.MutableLiveData
import com.amazingstar.datasource.UserRepository
import com.amazingstar.network.APIClient
import com.amazingstar.network.APIinterface

class UserDataModel {
    fun getArea(context: Context): MutableLiveData<AllArea> {
        val apInterface: APIinterface =
            APIClient.newRequestRetrofit(context).create(APIinterface::class.java)
        val userRepository = UserRepository(apInterface)
        return userRepository.getArea("")
    }
}