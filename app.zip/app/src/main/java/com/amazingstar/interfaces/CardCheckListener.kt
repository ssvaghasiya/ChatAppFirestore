package com.amazingstar.interfaces


interface CardCheckListener {
    fun onSuccess()
    fun onFail()
}