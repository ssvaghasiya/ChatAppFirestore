package com.amazingstar.interfaces

import android.view.View

interface BusinessBottomBarClickListener {

    fun onBottomBarClickListener(view : View?,value : String?)
}