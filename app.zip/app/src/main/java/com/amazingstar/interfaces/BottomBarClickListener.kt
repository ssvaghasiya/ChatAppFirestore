package com.amazingstar.interfaces

import android.view.View

interface BottomBarClickListener {

    fun onBottomBarClickListener(view : View?,value : String?)
}