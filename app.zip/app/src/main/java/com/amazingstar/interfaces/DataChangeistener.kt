package com.amazingstar.interfaces

interface DataChangeistener {

    fun onDataChanged(obj: Any)
}