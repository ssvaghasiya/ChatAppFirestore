package com.amazingstar.interfaces

interface ClickListener {
    fun onClick(obj: Any)
}