package com.amazingstar.interfaces

import java.util.*

interface DateEventListener {
    abstract fun onDateSelected(date: Date)
}