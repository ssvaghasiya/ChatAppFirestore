package com.amazingstar.interfaces

interface PopupCloseListener {
    fun onClose()
}